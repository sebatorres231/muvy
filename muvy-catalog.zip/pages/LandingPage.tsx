import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { getProducts } from '../services/productService';
import ProductCard from '../components/ProductCard';
import SkeletonCard from '../components/SkeletonCard';

const LandingPage: React.FC = () => {
    const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchFeatured = async () => {
            try {
                const allProducts = await getProducts();
                // Get 4 random products to feature
                const shuffled = allProducts.sort(() => 0.5 - Math.random());
                setFeaturedProducts(shuffled.slice(0, 4));
            } catch (error) {
                console.error("Could not fetch featured products", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchFeatured();
    }, []);

    return (
        <div className="animate-fade-in">
            {/* Hero Section */}
            <section className="bg-teal-50">
                <div className="container mx-auto px-4 py-20 text-center">
                    <h1 className="text-4xl md:text-6xl font-extrabold text-teal-700">El cuidado que tus pies merecen.</h1>
                    <p className="mt-4 text-lg md:text-xl text-slate-600 max-w-2xl mx-auto">Descubre nuestra colección de productos de alta calidad, diseñados para revitalizar y embellecer tus pies.</p>
                    <Link
                        to="/catalog"
                        className="mt-8 inline-block bg-teal-600 text-white font-bold py-3 px-8 rounded-full text-lg hover:bg-teal-700 transition-all duration-300 transform hover:scale-105"
                    >
                        Explorar Catálogo
                    </Link>
                </div>
            </section>

            {/* Features Section */}
            <section className="container mx-auto px-4 py-16">
                 <div className="grid md:grid-cols-3 gap-10 text-center">
                    <div className="p-6">
                         <h3 className="text-xl font-bold text-slate-800">Ingredientes de Calidad</h3>
                         <p className="mt-2 text-slate-600">Fórmulas efectivas con ingredientes naturales y probados.</p>
                    </div>
                     <div className="p-6">
                         <h3 className="text-xl font-bold text-slate-800">Resultados Visibles</h3>
                         <p className="mt-2 text-slate-600">Siente la diferencia desde el primer uso.</p>
                    </div>
                     <div className="p-6">
                         <h3 className="text-xl font-bold text-slate-800">Pedido Fácil por WhatsApp</h3>
                         <p className="mt-2 text-slate-600">Ordena tus productos favoritos con un solo clic.</p>
                    </div>
                </div>
            </section>
            
            {/* Featured Products Section */}
            <section className="bg-slate-100 py-16">
                 <div className="container mx-auto px-4">
                    <h2 className="text-3xl font-bold text-center text-slate-800 mb-10">Productos Destacados</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        {isLoading ? (
                            Array.from({ length: 4 }).map((_, index) => <SkeletonCard key={index} />)
                        ) : (
                            featuredProducts.map(product => <ProductCard key={product.id} product={product} />)
                        )}
                    </div>
                 </div>
            </section>
        </div>
    );
};

export default LandingPage;