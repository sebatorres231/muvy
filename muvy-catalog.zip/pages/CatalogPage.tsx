import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Product } from '../types';
import { getProducts } from '../services/productService';
import CategoryFilters from '../components/CategoryFilters';
import ProductGrid from '../components/ProductGrid';
import SearchIcon from '../components/icons/SearchIcon';


const CatalogPage: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState<string>('');
    const [currentCategory, setCurrentCategory] = useState<string>('all');

    useEffect(() => {
        const fetchProducts = async () => {
            setIsLoading(true);
            try {
                const fetchedProducts = await getProducts();
                setProducts(fetchedProducts);
                setError(null);
            } catch (err) {
                setError('No se pudieron cargar los productos. Por favor, intente de nuevo más tarde.');
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };

        fetchProducts();
    }, []);

    const categories = useMemo(() => {
        if (products.length === 0) return [];
        return ['all', ...new Set(products.map(p => p.category))];
    }, [products]);

    const filteredProducts = useMemo(() => {
        return products.filter(product => {
            const matchesCategory = currentCategory === 'all' || product.category === currentCategory;
            const matchesSearch = searchTerm === '' ||
                product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                product.description.toLowerCase().includes(searchTerm.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [products, currentCategory, searchTerm]);


    const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSearchTerm(event.target.value);
    };

    const handleCategoryChange = (category: string) => {
        setCurrentCategory(category);
    };

    const handleClearFilters = useCallback(() => {
        setSearchTerm('');
        setCurrentCategory('all');
    }, []);

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="mb-8 text-center">
                <h1 className="text-4xl font-bold text-slate-800">Nuestro Catálogo</h1>
                <p className="mt-2 text-slate-600">Encuentra el tratamiento perfecto para tus pies.</p>
                <div className="relative w-full max-w-lg mx-auto mt-6">
                    <input
                        id="search-input"
                        type="text"
                        placeholder="Buscar cremas, exfoliantes..."
                        value={searchTerm}
                        onChange={handleSearchChange}
                        aria-label="Buscar productos"
                        className="w-full pl-12 pr-4 py-3 border border-slate-300 rounded-full text-base text-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500 transition-shadow"
                    />
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400">
                        <SearchIcon />
                    </div>
                </div>
            </div>

            {error && <div className="text-center text-red-500 mt-10">{error}</div>}
            
            {!error && products.length > 0 && (
                <CategoryFilters
                    categories={categories}
                    currentCategory={currentCategory}
                    onCategoryChange={handleCategoryChange}
                />
            )}
            
            {!error && (
                 <ProductGrid 
                    products={filteredProducts} 
                    isLoading={isLoading}
                    onClearFilters={handleClearFilters}
                />
            )}

            {!isLoading && !error && products.length === 0 && (
                <div className="text-center text-slate-500 mt-10 py-16 bg-slate-100 rounded-xl">
                    <h2 className="text-2xl font-bold">La tienda se está preparando.</h2>
                    <p className="mt-2">¡Vuelve pronto para ver nuestros productos!</p>
                </div>
            )}
        </div>
    );
};

export default CatalogPage;