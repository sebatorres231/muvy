import React, { useState } from 'react';
import AdminProductList from '../components/admin/AdminProductList';
import AdminOrderList from '../components/admin/AdminOrderList';

type AdminTab = 'products' | 'orders';

const AdminPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AdminTab>('products');

    const getTabClass = (tabName: AdminTab) => {
        return activeTab === tabName
            ? 'border-teal-500 text-teal-600'
            : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300';
    };

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-6">Panel de Administración</h1>
            
            <div className="border-b border-slate-200 mb-6">
                <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                    <button
                        onClick={() => setActiveTab('products')}
                        className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors ${getTabClass('products')}`}
                    >
                        Gestión de Productos
                    </button>
                    <button
                        onClick={() => setActiveTab('orders')}
                        className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors ${getTabClass('orders')}`}
                    >
                        Gestión de Pedidos
                    </button>
                </nav>
            </div>

            <div>
                {activeTab === 'products' && <AdminProductList />}
                {activeTab === 'orders' && <AdminOrderList />}
            </div>
        </div>
    );
};

export default AdminPage;