import React, { useState, useCallback } from 'react';
import { generateProductCopy } from '../services/aiService';
import { AIWriterFormData, GeneratedCopy } from '../types';
import CloseIcon from './icons/CloseIcon';
import SparklesIcon from './icons/SparklesIcon';
import CopyIcon from './icons/CopyIcon';

interface AIWriterModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const AIWriterModal: React.FC<AIWriterModalProps> = ({ isOpen, onClose }) => {
    const [formData, setFormData] = useState<AIWriterFormData>({
        productName: '',
        category: '',
        keyIngredients: '',
        targetProblem: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [result, setResult] = useState<GeneratedCopy | null>(null);
    const [copySuccess, setCopySuccess] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleCopy = useCallback(() => {
        if (result) {
            navigator.clipboard.writeText(JSON.stringify(result, null, 2)).then(() => {
                setCopySuccess('¡Copiado!');
                setTimeout(() => setCopySuccess(''), 2000);
            }, () => {
                setCopySuccess('Error al copiar');
                 setTimeout(() => setCopySuccess(''), 2000);
            });
        }
    }, [result]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);
        setResult(null);
        setCopySuccess('');

        try {
            const generatedCopy = await generateProductCopy(formData);
            setResult(generatedCopy);
        } catch (err: any) {
            setError(err.message || 'Ocurrió un error inesperado.');
        } finally {
            setIsLoading(false);
        }
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center p-4 animate-fade-in-fast" onClick={onClose}>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col relative" onClick={e => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors z-10" aria-label="Cerrar modal">
                    <CloseIcon />
                </button>
                
                <div className="p-6 border-b border-slate-200">
                    <h2 className="text-xl font-bold text-slate-800">Asistente de Copywriting AI</h2>
                    <p className="text-sm text-slate-500 mt-1">Completa los campos para generar un texto de marketing atractivo.</p>
                </div>

                <div className="flex-grow overflow-y-auto p-6">
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="productName" className="block text-sm font-medium text-slate-700 mb-1">Nombre del Producto</label>
                            <input type="text" name="productName" id="productName" value={formData.productName} onChange={handleInputChange} required className="form-input" placeholder="Ej: Crema Hidratante Intensiva"/>
                        </div>
                        <div>
                            <label htmlFor="category" className="block text-sm font-medium text-slate-700 mb-1">Categoría</label>
                            <input type="text" name="category" id="category" value={formData.category} onChange={handleInputChange} required className="form-input" placeholder="Ej: cremas"/>
                        </div>
                        <div>
                            <label htmlFor="keyIngredients" className="block text-sm font-medium text-slate-700 mb-1">Ingredientes Clave</label>
                            <textarea name="keyIngredients" id="keyIngredients" value={formData.keyIngredients} onChange={handleInputChange} required rows={3} className="form-input" placeholder="Ej: Urea, Aceite de Almendras, Vitamina E"></textarea>
                        </div>
                        <div>
                            <label htmlFor="targetProblem" className="block text-sm font-medium text-slate-700 mb-1">Problema que Resuelve / Beneficio Principal</label>
                            <textarea name="targetProblem" id="targetProblem" value={formData.targetProblem} onChange={handleInputChange} required rows={3} className="form-input" placeholder="Ej: Pies secos y talones agrietados"></textarea>
                        </div>
                        <button type="submit" disabled={isLoading} className="w-full bg-teal-600 text-white font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-teal-700 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 disabled:bg-teal-400 disabled:cursor-not-allowed">
                            {isLoading ? (
                                <>
                                 <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Generando...
                                </>
                            ) : (
                                <>
                                <SparklesIcon />
                                Generar Texto
                                </>
                            )}
                        </button>
                    </form>
                    
                    {error && <div className="mt-4 text-center text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</div>}
                    
                    {result && (
                        <div className="mt-6 pt-6 border-t border-slate-200">
                             <h3 className="text-lg font-bold text-slate-800 mb-3">Resultado Generado:</h3>
                             <div className="bg-slate-100 rounded-lg p-4 relative font-mono text-sm text-slate-700">
                                <button onClick={handleCopy} className="absolute top-2 right-2 bg-white p-1.5 rounded-md text-slate-500 hover:bg-slate-200 hover:text-slate-700 transition-all text-xs">
                                    {copySuccess ? copySuccess : <CopyIcon />}
                                </button>
                                <pre><code>{JSON.stringify(result, null, 2)}</code></pre>
                             </div>
                        </div>
                    )}
                </div>
            </div>
            <style>{`
                .form-input {
                    display: block;
                    width: 100%;
                    border-radius: 0.5rem;
                    border: 1px solid #cbd5e1;
                    padding: 0.5rem 0.75rem;
                    font-size: 0.875rem;
                    color: #334155;
                    transition: box-shadow 0.15s ease-in-out, border-color 0.15s ease-in-out;
                }
                .form-input:focus {
                    outline: none;
                    border-color: #14b8a6;
                    box-shadow: 0 0 0 2px rgba(20, 184, 166, 0.3);
                }
                @keyframes fade-in-fast {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                .animate-fade-in-fast {
                    animation: fade-in-fast 0.2s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default AIWriterModal;