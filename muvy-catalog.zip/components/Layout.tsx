import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';

const Layout: React.FC = () => {
    return (
        <div className="bg-slate-50 min-h-screen font-sans text-slate-800 flex flex-col">
            <Navbar />
            <main className="flex-grow">
                <Outlet />
            </main>
            <footer className="text-center py-6 mt-10 text-slate-500 text-sm border-t border-slate-200">
                <p>&copy; {new Date().getFullYear()} Muvy. All rights reserved.</p>
            </footer>
        </div>
    );
};

export default Layout;