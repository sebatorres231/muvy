import React from 'react';
import { Product } from '../types';
import WhatsappIcon from './icons/WhatsappIcon';
import { createOrder } from '../services/orderService';

interface ProductCardProps {
    product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
    const handleWhatsAppOrder = () => {
        // 1. Log the order in the system
        createOrder(product);

        // 2. Open WhatsApp
        const message = `¡Hola! Quisiera pedir el siguiente producto: *${product.name}* - Precio: $${product.price.toFixed(2)}`;
        const encodedMessage = encodeURIComponent(message);
        window.open(`https://wa.me/?text=${encodedMessage}`, '_blank', 'noopener,noreferrer');
    };

    return (
        <div className="product-card bg-white rounded-xl shadow-md overflow-hidden flex flex-col group transition-all duration-300 ease-in-out hover:shadow-xl hover:-translate-y-2 animate-fade-in">
            <div className="relative">
                <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
                    loading="lazy"
                />
            </div>
            <div className="p-5 flex flex-col flex-grow">
                 <span className="text-xs font-semibold text-teal-600 bg-teal-50 px-2 py-1 rounded-full self-start mb-2">
                    {product.category.charAt(0).toUpperCase() + product.category.slice(1)}
                </span>
                <h3 className="text-lg font-bold text-slate-800 leading-tight truncate" title={product.name}>{product.name}</h3>
                <p className="text-sm text-slate-600 flex-grow my-2 h-10 overflow-hidden text-ellipsis">{product.description}</p>
                <p className="text-2xl font-extrabold text-slate-900 my-4 self-start">${product.price.toFixed(2)}</p>
                <button
                    onClick={handleWhatsAppOrder}
                    className="mt-auto w-full bg-green-500 text-white font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 hover:bg-green-600 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 transform group-hover:scale-105"
                    aria-label={`Pedir ${product.name} por WhatsApp`}
                >
                    <WhatsappIcon />
                    Pedir por WhatsApp
                </button>
            </div>
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-in-out forwards;
                }
            `}</style>
        </div>
    );
};

export default ProductCard;