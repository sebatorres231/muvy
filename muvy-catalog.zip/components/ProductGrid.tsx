import React from 'react';
import { Product } from '../types';
import ProductCard from './ProductCard';
import NoResults from './NoResults';
import SkeletonCard from './SkeletonCard';

interface ProductGridProps {
    products: Product[];
    isLoading: boolean;
    onClearFilters: () => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, isLoading, onClearFilters }) => {
    if (isLoading) {
        return (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {Array.from({ length: 8 }).map((_, index) => (
                    <SkeletonCard key={index} />
                ))}
            </div>
        );
    }

    if (products.length === 0) {
        return <NoResults onClearFilters={onClearFilters} />;
    }

    return (
        <div id="product-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {products.map(product => (
                <ProductCard key={product.id} product={product} />
            ))}
        </div>
    );
};

export default ProductGrid;