import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar: React.FC = () => {
    const activeLinkClass = 'bg-teal-100 text-teal-700';
    const inactiveLinkClass = 'text-slate-600 hover:bg-slate-100 hover:text-slate-800';

    return (
        <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-30 border-b border-slate-200">
            <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
                <NavLink to="/" className="text-2xl md:text-3xl font-bold text-teal-600">
                    Muvy
                </NavLink>
                <div className="flex items-center gap-2 sm:gap-4">
                    <NavLink
                        to="/"
                        end
                        className={({ isActive }) => `${isActive ? activeLinkClass : inactiveLinkClass} px-3 py-2 rounded-md text-sm font-medium transition-colors`}
                    >
                        Inicio
                    </NavLink>
                    <NavLink
                        to="/catalog"
                        className={({ isActive }) => `${isActive ? activeLinkClass : inactiveLinkClass} px-3 py-2 rounded-md text-sm font-medium transition-colors`}
                    >
                        Catálogo
                    </NavLink>
                    <NavLink
                        to="/admin"
                        className={({ isActive }) => `${isActive ? activeLinkClass : inactiveLinkClass} px-3 py-2 rounded-md text-sm font-medium transition-colors`}
                    >
                        Admin
                    </NavLink>
                </div>
            </nav>
        </header>
    );
};

export default Navbar;