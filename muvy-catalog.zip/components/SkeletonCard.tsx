import React from 'react';

const SkeletonCard: React.FC = () => (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-5 animate-pulse">
            <div className="h-48 bg-slate-200 rounded-md"></div>
            <div className="mt-4">
                <div className="h-4 bg-slate-200 rounded w-1/4 mb-4"></div>
                <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-full mb-1"></div>
                <div className="h-4 bg-slate-200 rounded w-5/6 mb-4"></div>
                <div className="h-8 bg-slate-200 rounded w-1/3 mb-6"></div>
                <div className="h-11 bg-slate-200 rounded-lg w-full"></div>
            </div>
        </div>
    </div>
);

export default SkeletonCard;