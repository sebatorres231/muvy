import React from 'react';

interface NoResultsProps {
    onClearFilters: () => void;
}

const NoResults: React.FC<NoResultsProps> = ({ onClearFilters }) => {
    return (
        <div id="no-results-message" className="text-center py-16 px-4 text-slate-500 bg-slate-100 rounded-xl">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-16 w-16 text-slate-400" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5h.008v.008h-.008v-.008z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5h.008v.008h-.008v-.008zm-4.5 0h.008v.008h-.008v-.008z" />
            </svg>
            <h3 className="mt-4 text-xl font-bold text-slate-700">No se encontraron productos</h3>
            <p className="mt-2 max-w-md mx-auto">Prueba a cambiar los filtros, utilizar otras palabras en la búsqueda o restablecer la vista.</p>
            <button
                onClick={onClearFilters}
                className="mt-6 px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 rounded-lg shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-all"
            >
                Limpiar filtros y búsqueda
            </button>
        </div>
    );
};

export default NoResults;