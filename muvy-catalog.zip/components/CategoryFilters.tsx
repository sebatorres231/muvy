import React from 'react';

interface CategoryFiltersProps {
    categories: string[];
    currentCategory: string;
    onCategoryChange: (category: string) => void;
}

const CategoryFilters: React.FC<CategoryFiltersProps> = ({ categories, currentCategory, onCategoryChange }) => {
    return (
        <div id="category-filters" className="mb-8 flex flex-wrap justify-center gap-2">
            {categories.map(category => (
                <button
                    key={category}
                    onClick={() => onCategoryChange(category)}
                    aria-pressed={currentCategory === category}
                    className={`px-4 py-2 text-sm font-semibold rounded-full transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transform hover:scale-105
                        ${currentCategory === category 
                            ? 'bg-teal-600 text-white shadow-md' 
                            : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                        }`
                    }
                >
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                </button>
            ))}
        </div>
    );
};

export default CategoryFilters;