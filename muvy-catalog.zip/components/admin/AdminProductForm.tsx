import React, { useState, useEffect } from 'react';
import { Product } from '../../types';
import { addProduct, updateProduct } from '../../services/productService';
import CloseIcon from '../icons/CloseIcon';
import SparklesIcon from '../icons/SparklesIcon';
import AIWriterModal from '../AIWriterModal';

interface AdminProductFormProps {
    product: Product | null;
    onClose: (wasSaved: boolean) => void;
}

const AdminProductForm: React.FC<AdminProductFormProps> = ({ product, onClose }) => {
    const [formData, setFormData] = useState({
        name: '',
        category: '',
        description: '',
        price: ''
    });
    const [isSaving, setIsSaving] = useState(false);
    const [isAiWriterOpen, setIsAiWriterOpen] = useState(false);

    useEffect(() => {
        if (product) {
            setFormData({
                name: product.name,
                category: product.category,
                description: product.description,
                price: product.price.toString(),
            });
        } else {
            setFormData({ name: '', category: '', description: '', price: '' });
        }
    }, [product]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const productData = {
                name: formData.name,
                category: formData.category,
                description: formData.description,
                price: parseFloat(formData.price),
            };

            if (product) {
                await updateProduct({ ...product, ...productData });
            } else {
                await addProduct(productData);
            }
            onClose(true);
        } catch (error) {
            console.error("Failed to save product", error);
            alert("Error al guardar el producto.");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center p-4 animate-fade-in-fast" onClick={() => onClose(false)}>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col relative" onClick={e => e.stopPropagation()}>
                <button onClick={() => onClose(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors z-10" aria-label="Cerrar modal">
                    <CloseIcon />
                </button>
                
                <div className="p-6 border-b border-slate-200">
                    <h2 className="text-xl font-bold text-slate-800">{product ? 'Editar Producto' : 'Añadir Producto'}</h2>
                </div>
                
                <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto p-6 space-y-4">
                     <div>
                        <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Nombre</label>
                        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="form-input" />
                    </div>
                     <div>
                        <label htmlFor="category" className="block text-sm font-medium text-slate-700 mb-1">Categoría</label>
                        <input type="text" name="category" id="category" value={formData.category} onChange={handleChange} required className="form-input" />
                    </div>
                    <div>
                        <label htmlFor="price" className="block text-sm font-medium text-slate-700 mb-1">Precio</label>
                        <input type="number" name="price" id="price" value={formData.price} onChange={handleChange} required step="0.01" className="form-input" />
                    </div>
                     <div>
                        <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-1">Descripción</label>
                        <textarea name="description" id="description" value={formData.description} onChange={handleChange} required rows={4} className="form-input"></textarea>
                    </div>
                    <div>
                        <button type="button" onClick={() => setIsAiWriterOpen(true)} className="w-full justify-center text-sm flex items-center gap-2 px-3 py-2 font-semibold text-teal-700 bg-teal-50 rounded-lg shadow-sm hover:bg-teal-100 transition-all">
                            <SparklesIcon />
                            ¿Necesitas inspiración? Usa el Asistente AI para la descripción.
                        </button>
                    </div>
                    <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                        <button type="button" onClick={() => onClose(false)} className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors">Cancelar</button>
                        <button type="submit" disabled={isSaving} className="px-4 py-2 text-sm font-medium text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors disabled:bg-teal-400">
                            {isSaving ? 'Guardando...' : 'Guardar Producto'}
                        </button>
                    </div>
                </form>
            </div>
            {isAiWriterOpen && <AIWriterModal isOpen={isAiWriterOpen} onClose={() => setIsAiWriterOpen(false)} />}
            <style>{`.form-input{display:block;width:100%;border-radius:0.5rem;border:1px solid #cbd5e1;padding:0.5rem 0.75rem;font-size:0.875rem;color:#334155;transition:box-shadow .15s ease-in-out,border-color .15s ease-in-out}.form-input:focus{outline:0;border-color:#14b8a6;box-shadow:0 0 0 2px rgba(20,184,166,.3)}`}</style>
        </div>
    );
};

export default AdminProductForm;