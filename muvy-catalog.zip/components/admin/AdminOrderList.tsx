import React, { useState, useEffect, useCallback } from 'react';
import { Order } from '../../types';
import { getOrders, updateOrderStatus } from '../../services/orderService';

const AdminOrderList: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchOrders = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await getOrders();
            setOrders(data);
            setError(null);
        } catch (err) {
            setError('Failed to fetch orders');
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchOrders();
    }, [fetchOrders]);
    
    const handleCompleteOrder = async (orderId: number) => {
        try {
            await updateOrderStatus(orderId, 'completed');
            fetchOrders();
        } catch(err) {
            alert('Failed to update order status.');
        }
    };
    
    if (isLoading) return <p className="text-center text-slate-500">Cargando pedidos...</p>;
    if (error) return <p className="text-center text-red-500">{error}</p>;

    return (
        <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold text-slate-700 mb-4">Pedidos Recibidos</h2>
            {orders.length === 0 ? (
                 <p className="text-center text-slate-500 py-8">Aún no se han registrado pedidos.</p>
            ) : (
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200">
                        <thead className="bg-slate-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Producto</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Fecha</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Estado</th>
                                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Acción</span></th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-200">
                            {orders.map((order) => (
                                <tr key={order.id}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="flex items-center">
                                            <div className="flex-shrink-0 h-10 w-10">
                                                <img className="h-10 w-10 rounded-md object-cover" src={order.product.image} alt={order.product.name} />
                                            </div>
                                            <div className="ml-4">
                                                <div className="text-sm font-medium text-slate-900">{order.product.name}</div>
                                                <div className="text-sm text-slate-500">${order.product.price.toFixed(2)}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{new Date(order.timestamp).toLocaleString()}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                                            {order.status === 'pending' ? 'Pendiente' : 'Completado'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        {order.status === 'pending' && (
                                            <button 
                                                onClick={() => handleCompleteOrder(order.id)}
                                                className="text-white bg-green-500 hover:bg-green-600 text-xs font-bold py-1 px-3 rounded-full transition-colors"
                                            >
                                                Marcar como Completado
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default AdminOrderList;