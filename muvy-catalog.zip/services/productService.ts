import { Product } from '../types';
import { allProducts as initialProducts } from './productData';

const PRODUCTS_STORAGE_KEY = 'muvy_products';

const initializeProducts = (): Product[] => {
    try {
        const storedProducts = localStorage.getItem(PRODUCTS_STORAGE_KEY);
        if (storedProducts) {
            return JSON.parse(storedProducts);
        } else {
            localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(initialProducts));
            return initialProducts;
        }
    } catch (error) {
        console.error("Error with localStorage:", error);
        return initialProducts;
    }
};

let products: Product[] = initializeProducts();

const persistProducts = () => {
    try {
        localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
    } catch (error) {
        console.error("Failed to persist products to localStorage:", error);
    }
};

export const getProducts = async (): Promise<Product[]> => {
    products = initializeProducts();
    return new Promise(resolve => {
        setTimeout(() => {
            resolve([...products]);
        }, 500);
    });
};

export const getProductById = async (id: number): Promise<Product | undefined> => {
     return new Promise(resolve => {
        setTimeout(() => {
            resolve(products.find(p => p.id === id));
        }, 100);
    });
};

export const addProduct = async (productData: Omit<Product, 'id' | 'image'>): Promise<Product> => {
    const newProduct: Product = {
        ...productData,
        id: Date.now(),
        image: `https://picsum.photos/seed/muvy${Date.now()}/400/300`
    };
    products.unshift(newProduct);
    persistProducts();
    return new Promise(resolve => resolve(newProduct));
};

export const updateProduct = async (updatedProduct: Product): Promise<Product> => {
    const index = products.findIndex(p => p.id === updatedProduct.id);
    if (index !== -1) {
        products[index] = updatedProduct;
        persistProducts();
        return new Promise(resolve => resolve(updatedProduct));
    }
    throw new Error('Product not found');
};

export const deleteProduct = async (id: number): Promise<void> => {
    const initialLength = products.length;
    products = products.filter(p => p.id !== id);
    if (products.length === initialLength) {
        throw new Error('Product not found for deletion');
    }
    persistProducts();
    return new Promise(resolve => resolve());
};