import { Product } from '../types';

export const allProducts: Product[] = [
    {
        id: 1,
        name: 'Crema Hidratante Intensiva',
        category: 'cremas',
        description: 'Crema para pies secos y agrietados. Hidratación profunda por 24 horas.',
        price: 15.50,
        image: 'https://picsum.photos/seed/muvy1/400/300'
    },
    {
        id: 2,
        name: 'Sales de Baño Relajantes',
        category: 'exfoliantes',
        description: 'Sales minerales con lavanda para un baño de pies relajante y desinflamante.',
        price: 12.00,
        image: 'https://picsum.photos/seed/muvy2/400/300'
    },
    {
        id: 3,
        name: 'Exfoliante de Azúcar y Menta',
        category: 'exfoliantes',
        description: 'Elimina células muertas y suaviza la piel con este exfoliante natural.',
        price: 18.75,
        image: 'https://picsum.photos/seed/muvy3/400/300'
    },
    {
        id: 4,
        name: 'Aceite para Cutículas con Vitamina E',
        category: 'tratamientos',
        description: 'Aceite nutritivo para fortalecer y suavizar las cutículas de los pies.',
        price: 9.99,
        image: 'https://picsum.photos/seed/muvy4/400/300'
    },
    {
        id: 5,
        name: 'Lima de Pies Profesional',
        category: 'accesorios',
        description: 'Lima de doble cara para eliminar durezas y callosidades de forma eficaz y segura.',
        price: 7.50,
        image: 'https://picsum.photos/seed/muvy5/400/300'
    },
    {
        id: 6,
        name: 'Gel Frío para Piernas Cansadas',
        category: 'tratamientos',
        description: 'Alivio inmediato para piernas y pies cansados con efecto frío y mentol.',
        price: 22.00,
        image: 'https://picsum.photos/seed/muvy6/400/300'
    },
    {
        id: 7,
        name: 'Talco Desodorante para Pies',
        category: 'cremas',
        description: 'Polvo de talco con acción desodorante y anti-transpirante para mantener los pies frescos.',
        price: 6.80,
        image: 'https://picsum.photos/seed/muvy7/400/300'
    },
    {
        id: 8,
        name: 'Kit de Pedicura Completo',
        category: 'accesorios',
        description: 'Set completo con todas las herramientas necesarias para una pedicura perfecta en casa.',
        price: 35.00,
        image: 'https://picsum.photos/seed/muvy8/400/300'
    },
    {
        id: 9,
        name: 'Mascarilla Reparadora de Noche',
        category: 'tratamientos',
        description: 'Una mascarilla intensiva que repara los talones agrietados mientras duermes.',
        price: 19.95,
        image: 'https://picsum.photos/seed/muvy9/400/300'
    },
    {
        id: 10,
        name: 'Separadores de Dedos de Silicona',
        category: 'accesorios',
        description: 'Juego de separadores de dedos cómodos y reutilizables para un esmaltado perfecto.',
        price: 4.99,
        image: 'https://picsum.photos/seed/muvy10/400/300'
    },
    {
        id: 11,
        name: 'Bomba Efervescente para Pies',
        category: 'exfoliantes',
        description: 'Bomba efervescente con aceites esenciales para un remojo de pies de lujo.',
        price: 8.50,
        image: 'https://picsum.photos/seed/muvy11/400/300'
    },
    {
        id: 12,
        name: 'Crema para Callos con Urea',
        category: 'cremas',
        description: 'Fórmula potente con urea para ablandar y eliminar callosidades persistentes.',
        price: 16.25,
        image: 'https://picsum.photos/seed/muvy12/400/300'
    }
];