import { Order, Product } from '../types';

const ORDERS_STORAGE_KEY = 'muvy_orders';

const initializeOrders = (): Order[] => {
    try {
        const storedOrders = localStorage.getItem(ORDERS_STORAGE_KEY);
        return storedOrders ? JSON.parse(storedOrders) : [];
    } catch (error) {
        console.error("Error initializing orders from localStorage:", error);
        return [];
    }
};

let orders: Order[] = initializeOrders();

const persistOrders = () => {
    try {
        localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    } catch (error) {
        console.error("Failed to persist orders to localStorage:", error);
    }
};

export const getOrders = async (): Promise<Order[]> => {
    orders = initializeOrders();
    return new Promise(resolve => {
        setTimeout(() => {
            resolve([...orders].sort((a, b) => b.id - a.id));
        }, 300);
    });
};

export const createOrder = async (product: Product): Promise<Order> => {
    const newOrder: Order = {
        id: Date.now(),
        product,
        timestamp: new Date().toISOString(),
        status: 'pending'
    };
    orders.unshift(newOrder);
    persistOrders();
    return new Promise(resolve => resolve(newOrder));
};

export const updateOrderStatus = async (orderId: number, status: 'completed'): Promise<Order> => {
    const orderIndex = orders.findIndex(o => o.id === orderId);
    if (orderIndex === -1) {
        throw new Error('Order not found');
    }
    orders[orderIndex].status = status;
    persistOrders();
    return new Promise(resolve => resolve(orders[orderIndex]));
};