import React, { useState } from 'react';
import AdminProductList from '../components/admin/AdminProductList';
import AdminOrderList from '../components/admin/AdminOrderList';

type AdminTab = 'products' | 'orders';

const AdminPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AdminTab>('products');

    const renderContent = () => {
        switch (activeTab) {
            case 'products':
                return <AdminProductList />;
            case 'orders':
                return <AdminOrderList />;
            default:
                return null;
        }
    };

    const getTabClass = (tabName: AdminTab) => {
        return `px-4 py-2 font-semibold rounded-md transition-colors text-sm ${
            activeTab === tabName 
            ? 'bg-slate-800 text-white' 
            : 'text-slate-600 hover:bg-slate-200'
        }`;
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-sm">
            <h1 className="text-3xl font-bold text-slate-800 mb-6">Panel de Administración</h1>
            <div className="flex border-b border-slate-200 mb-6">
                <button onClick={() => setActiveTab('products')} className={getTabClass('products')}>
                    Gestionar Productos
                </button>
                <button onClick={() => setActiveTab('orders')} className={getTabClass('orders')}>
                    Ver Pedidos
                </button>
            </div>
            <div>
                {renderContent()}
            </div>
        </div>
    );
};

export default AdminPage;
