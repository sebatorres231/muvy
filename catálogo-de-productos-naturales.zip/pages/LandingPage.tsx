import React from 'react';
import { Link } from 'react-router-dom';

const LandingPage: React.FC = () => {
    return (
        <div className="text-center py-16 md:py-24">
            <div 
                className="absolute inset-0 -z-10 h-full w-full bg-white bg-[linear-gradient(to_right,#f0f0f0_1px,transparent_1px),linear-gradient(to_bottom,#f0f0f0_1px,transparent_1px)] bg-[size:6rem_4rem]">
                <div className="absolute bottom-0 left-0 right-0 top-0 bg-[radial-gradient(circle_500px_at_50%_200px,#d5c5f0,transparent)]"></div>
            </div>

            <h1 className="text-4xl md:text-6xl font-extrabold text-slate-800 tracking-tight">
                El Arte del Cuidado Natural
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg text-slate-600">
                Descubre nuestra colección exclusiva de productos formulados con los mejores ingredientes de la naturaleza para nutrir tu piel.
            </p>
            <div className="mt-8 flex justify-center gap-4">
                <Link 
                    to="/catalog" 
                    className="inline-block bg-slate-800 text-white font-semibold px-8 py-3 rounded-lg shadow-md hover:bg-slate-700 transition-transform transform hover:scale-105"
                >
                    Explorar Catálogo
                </Link>
            </div>
        </div>
    );
};

export default LandingPage;
