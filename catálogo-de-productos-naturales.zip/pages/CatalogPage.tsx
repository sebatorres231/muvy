import React, { useState, useEffect, useMemo } from 'react';
import { Product, Category } from '../types';
import { getProducts } from '../services/productService';
import ProductGrid from '../components/ProductGrid';
import CategoryFilters from '../components/CategoryFilters';
import SearchIcon from '../components/icons/SearchIcon';
import NoResults from '../components/NoResults';
import SkeletonCard from '../components/SkeletonCard';

const ALL_CATEGORIES: Category[] = ['Cuidado de Pies', 'Cuidado de Manos', 'Cuidado Corporal'];

const CatalogPage: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);

    useEffect(() => {
        const fetchProducts = async () => {
            setIsLoading(true);
            try {
                const data = await getProducts();
                setProducts(data);
            } catch (error) {
                console.error("Failed to fetch products:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchProducts();
    }, []);

    const filteredProducts = useMemo(() => {
        return products.filter(product => {
            const matchesCategory = selectedCategory ? product.category === selectedCategory : true;
            const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [products, searchQuery, selectedCategory]);

    return (
        <div>
            <div className="mb-8 p-6 bg-white rounded-lg shadow-sm">
                <h1 className="text-3xl font-bold text-slate-800 mb-2">Nuestro Catálogo</h1>
                <p className="text-slate-500">Encuentra el producto perfecto para ti.</p>
                <div className="mt-6 flex flex-col md:flex-row gap-4">
                    <div className="relative flex-grow">
                        <input
                            type="text"
                            placeholder="Buscar por nombre..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-slate-400 focus:outline-none"
                            aria-label="Buscar productos"
                        />
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                           <SearchIcon />
                        </div>
                    </div>
                </div>
                 <CategoryFilters
                    categories={ALL_CATEGORIES}
                    selectedCategory={selectedCategory}
                    onSelectCategory={setSelectedCategory}
                />
            </div>

            {isLoading ? (
                 <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
                 </div>
            ) : filteredProducts.length > 0 ? (
                <ProductGrid products={filteredProducts} />
            ) : (
                <NoResults onClear={() => { setSearchQuery(''); setSelectedCategory(null); }} />
            )}
        </div>
    );
};

export default CatalogPage;
