import { Product } from '../types';
import { initialProducts } from './productData';

let products: Product[] = [...initialProducts];

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getProducts = async (): Promise<Product[]> => {
  await delay(500);
  return [...products];
};

export const getProductById = async (id: string): Promise<Product | undefined> => {
  await delay(200);
  return products.find(p => p.id === id);
};

export const addProduct = async (product: Omit<Product, 'id'>): Promise<Product> => {
  await delay(300);
  const newProduct: Product = {
    ...product,
    id: Date.now().toString(),
  };
  products.unshift(newProduct);
  return newProduct;
};

export const updateProduct = async (updatedProduct: Product): Promise<Product> => {
  await delay(300);
  products = products.map(p => (p.id === updatedProduct.id ? updatedProduct : p));
  return updatedProduct;
};

export const deleteProduct = async (id: string): Promise<void> => {
  await delay(400);
  products = products.filter(p => p.id !== id);
};
