import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const PROMPT_TEMPLATE = `
Eres un experto en marketing de productos de belleza y cuidado personal.
Tu tarea es crear una descripción de producto atractiva, breve y vendedora.

**Reglas:**
- El tono debe ser inspirador y resaltar los beneficios.
- No uses más de 50 palabras.
- Evita clichés y frases genéricas.
- Sé creativo y memorable.
- Responde únicamente con la descripción, sin introducciones ni despedidas.

**Basado en las siguientes palabras clave, crea la descripción:**
{keywords}
`;

export const generateProductDescription = async (keywords: string): Promise<string> => {
    try {
        if (!process.env.API_KEY) {
            throw new Error("API key for Gemini is not configured.");
        }
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = PROMPT_TEMPLATE.replace('{keywords}', keywords);

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
        });

        const text = response.text.trim();
        return text;
    } catch (error) {
        console.error("Error generating product description:", error);
        return "Hubo un error al generar la descripción. Por favor, inténtalo de nuevo.";
    }
};
