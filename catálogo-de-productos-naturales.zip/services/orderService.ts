import { Order } from '../types';

let orders: Order[] = [];

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getOrders = async (): Promise<Order[]> => {
    await delay(500);
    return [...orders];
};

export const addOrder = async (order: Omit<Order, 'id' | 'date'>): Promise<Order> => {
    await delay(300);
    const newOrder: Order = {
        ...order,
        id: Date.now().toString(),
        date: new Date().toISOString(),
    };
    orders.unshift(newOrder);
    return newOrder;
};
