export type Category = 'Cuidado de Pies' | 'Cuidado de Manos' | 'Cuidado Corporal';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  imageUrl: string;
  stock: number;
}

export interface Order {
  id: string;
  customerName: string;
  items: { productId: string; quantity: number }[];
  total: number;
  date: string;
}
