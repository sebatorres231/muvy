import React from 'react';

const SparklesIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M4 17v4M2 19h4M10 3l.707.707a1 1 0 001.414 0L13 3l-.707-.707a1 1 0 00-1.414 0L10 3zm5 4l-1.414-1.414a1 1 0 010-1.414l1.414-1.414a1 1 0 011.414 0l1.414 1.414a1 1 0 010 1.414L15 7zm-5 10l.707.707a1 1 0 001.414 0L13 17l-.707-.707a1 1 0 00-1.414 0L10 17z" />
    </svg>
);

export default SparklesIcon;
