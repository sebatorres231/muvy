import React from 'react';
import { Product } from '../types';
import WhatsappIcon from './icons/WhatsappIcon';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
    const whatsappMessage = `Hola, estoy interesado/a en el producto "${product.name}". ¿Podrían darme más información?`;
    const whatsappUrl = `https://api.whatsapp.com/send?phone=TUNUMERO&text=${encodeURIComponent(whatsappMessage)}`;

    return (
        <div className="bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 flex flex-col">
            <img src={product.imageUrl} alt={product.name} className="w-full h-48 object-cover" />
            <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-lg font-semibold text-slate-800 truncate">{product.name}</h3>
                <p className="text-sm text-slate-500 mt-1 flex-grow">{product.description}</p>
                <div className="mt-4 flex justify-between items-center">
                    <span className="text-xl font-bold text-slate-800">${product.price.toFixed(2)}</span>
                    <a
                        href={whatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-green-500 text-white px-3 py-2 rounded-md hover:bg-green-600 transition-colors flex items-center gap-2 text-sm"
                        aria-label={`Pedir ${product.name} por WhatsApp`}
                    >
                        <WhatsappIcon />
                        <span>Pedir</span>
                    </a>
                </div>
            </div>
        </div>
    );
};

export default ProductCard;
