import React from 'react';

const SkeletonCard: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden animate-skeleton">
      <div className="w-full h-48 bg-slate-200"></div>
      <div className="p-4">
        <div className="h-6 w-3/4 bg-slate-200 rounded"></div>
        <div className="mt-2 h-4 w-full bg-slate-200 rounded"></div>
        <div className="mt-1 h-4 w-5/6 bg-slate-200 rounded"></div>
        <div className="mt-4 flex justify-between items-center">
          <div className="h-8 w-1/3 bg-slate-200 rounded"></div>
          <div className="h-10 w-1/2 bg-slate-200 rounded-md"></div>
        </div>
      </div>
    </div>
  );
};

export default SkeletonCard;
