import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar: React.FC = () => {
    const activeLinkClass = 'text-slate-900 font-semibold';
    const inactiveLinkClass = 'text-slate-500 hover:text-slate-800 transition-colors';

    return (
        <header className="bg-white/80 backdrop-blur-md sticky top-0 z-10 shadow-sm">
            <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
                <NavLink to="/" className="text-xl font-bold text-slate-800">
                    Naturalis
                </NavLink>
                <ul className="flex items-center space-x-6">
                    <li>
                        <NavLink 
                            to="/" 
                            className={({ isActive }) => isActive ? activeLinkClass : inactiveLinkClass}
                        >
                            Inicio
                        </NavLink>
                    </li>
                    <li>
                        <NavLink 
                            to="/catalog"
                             className={({ isActive }) => isActive ? activeLinkClass : inactiveLinkClass}
                        >
                            Catálogo
                        </NavLink>
                    </li>
                    <li>
                        <NavLink 
                            to="/admin"
                            className={({ isActive }) => isActive ? activeLinkClass : inactiveLinkClass}
                        >
                            Admin
                        </NavLink>
                    </li>
                </ul>
            </nav>
        </header>
    );
};

export default Navbar;
