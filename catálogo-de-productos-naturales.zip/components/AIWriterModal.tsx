import React, { useState } from 'react';
import { generateProductDescription } from '../services/aiService';
import CloseIcon from './icons/CloseIcon';
import CopyIcon from './icons/CopyIcon';

interface AIWriterModalProps {
  productName: string;
  onClose: () => void;
  onGenerate: (description: string) => void;
}

const AIWriterModal: React.FC<AIWriterModalProps> = ({ productName, onClose, onGenerate }) => {
    const [keywords, setKeywords] = useState(productName);
    const [isLoading, setIsLoading] = useState(false);
    const [generatedText, setGeneratedText] = useState('');
    const [hasCopied, setHasCopied] = useState(false);

    const handleGenerateClick = async () => {
        setIsLoading(true);
        setGeneratedText('');
        const result = await generateProductDescription(keywords || productName);
        setGeneratedText(result);
        setIsLoading(false);
    };

    const handleCopy = () => {
        navigator.clipboard.writeText(generatedText);
        setHasCopied(true);
        setTimeout(() => setHasCopied(false), 2000);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-lg font-bold text-slate-800">Asistente de Escritura AI</h2>
                        <button onClick={onClose} className="text-slate-500 hover:text-slate-800"><CloseIcon/></button>
                    </div>

                    <div>
                        <label htmlFor="keywords" className="block text-sm font-medium text-slate-600">Palabras clave</label>
                        <input
                            type="text"
                            id="keywords"
                            value={keywords}
                            onChange={(e) => setKeywords(e.target.value)}
                            className="mt-1 block w-full border border-slate-300 rounded-md shadow-sm py-2 px-3"
                            placeholder="Ej: crema reparadora, pies secos, karité"
                        />
                         <p className="text-xs text-slate-400 mt-1">Usa el nombre del producto o añade más detalles para guiar a la IA.</p>
                    </div>

                    <div className="mt-4">
                        <button onClick={handleGenerateClick} disabled={isLoading} className="w-full bg-slate-800 text-white font-semibold py-2 px-4 rounded-md hover:bg-slate-700 disabled:bg-slate-400 flex items-center justify-center">
                            {isLoading ? 'Generando...' : '✨ Generar Descripción'}
                        </button>
                    </div>

                    {generatedText && (
                        <div className="mt-6">
                            <h3 className="text-sm font-bold text-slate-600">Resultado:</h3>
                            <div className="mt-2 p-4 bg-slate-50 rounded-md border border-slate-200 relative">
                                <p className="text-slate-700">{generatedText}</p>
                                <button onClick={handleCopy} className="absolute top-2 right-2 p-1 text-slate-500 hover:bg-slate-200 rounded-md">
                                    <CopyIcon />
                                </button>
                                {hasCopied && <span className="absolute top-10 right-2 text-xs bg-slate-800 text-white rounded px-2 py-1">Copiado</span>}
                            </div>
                            <button onClick={() => onGenerate(generatedText)} className="mt-4 w-full bg-green-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-green-700">
                                Usar este texto
                            </button>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
};

export default AIWriterModal;
