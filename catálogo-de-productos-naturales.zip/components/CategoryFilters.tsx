import React from 'react';
import { Category } from '../types';

interface CategoryFiltersProps {
  categories: Category[];
  selectedCategory: Category | null;
  onSelectCategory: (category: Category | null) => void;
}

const CategoryFilters: React.FC<CategoryFiltersProps> = ({ categories, selectedCategory, onSelectCategory }) => {
  const baseStyle = "px-4 py-2 text-sm font-medium rounded-full transition-all duration-200";
  const activeStyle = "bg-slate-800 text-white shadow";
  const inactiveStyle = "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200";

  return (
    <div className="mt-4 flex flex-wrap gap-2">
       <button
          onClick={() => onSelectCategory(null)}
          className={`${baseStyle} ${!selectedCategory ? activeStyle : inactiveStyle}`}
          aria-pressed={!selectedCategory}
        >
          Todos
        </button>
      {categories.map(category => (
        <button
          key={category}
          onClick={() => onSelectCategory(category)}
          className={`${baseStyle} ${selectedCategory === category ? activeStyle : inactiveStyle}`}
          aria-pressed={selectedCategory === category}
        >
          {category}
        </button>
      ))}
    </div>
  );
};

export default CategoryFilters;
