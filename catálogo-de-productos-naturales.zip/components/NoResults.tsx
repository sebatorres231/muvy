import React from 'react';

interface NoResultsProps {
  onClear: () => void;
}

const NoResults: React.FC<NoResultsProps> = ({ onClear }) => {
  return (
    <div className="text-center py-16 px-6 bg-white rounded-lg shadow-sm">
      <h2 className="text-2xl font-semibold text-slate-700">No se encontraron productos</h2>
      <p className="mt-2 text-slate-500">
        Intenta ajustar tu búsqueda o filtros para encontrar lo que buscas.
      </p>
      <button
        onClick={onClear}
        className="mt-6 bg-slate-800 text-white font-semibold px-6 py-2 rounded-lg shadow-md hover:bg-slate-700 transition-colors"
      >
        Limpiar Filtros
      </button>
    </div>
  );
};

export default NoResults;
