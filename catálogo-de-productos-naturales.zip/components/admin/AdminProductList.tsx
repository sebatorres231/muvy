import React, { useState, useEffect, useCallback } from 'react';
import { Product } from '../../types';
import { getProducts, deleteProduct } from '../../services/productService';
import AdminProductForm from './AdminProductForm';
import EditIcon from '../icons/EditIcon';
import TrashIcon from '../icons/TrashIcon';

const AdminProductList: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);

    const fetchProducts = useCallback(async () => {
        setIsLoading(true);
        const data = await getProducts();
        setProducts(data);
        setIsLoading(false);
    }, []);

    useEffect(() => {
        fetchProducts();
    }, [fetchProducts]);

    const handleEdit = (product: Product) => {
        setEditingProduct(product);
        setIsFormOpen(true);
    };

    const handleDelete = async (id: string) => {
        if (window.confirm('¿Estás seguro de que quieres eliminar este producto?')) {
            await deleteProduct(id);
            await fetchProducts();
        }
    };
    
    const handleFormClose = () => {
        setIsFormOpen(false);
        setEditingProduct(null);
    };

    const handleFormSuccess = () => {
        handleFormClose();
        fetchProducts();
    };

    if (isLoading && !isFormOpen) {
        return <p>Cargando productos...</p>;
    }
    
    return (
        <div>
            {isFormOpen ? (
                <AdminProductForm 
                    product={editingProduct} 
                    onSuccess={handleFormSuccess} 
                    onClose={handleFormClose}
                />
            ) : (
                <>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-slate-700">Productos existentes</h2>
                        <button onClick={() => setIsFormOpen(true)} className="bg-slate-800 text-white font-semibold px-4 py-2 rounded-md hover:bg-slate-700">
                            Añadir Producto
                        </button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="min-w-full bg-white border border-slate-200">
                            <thead className="bg-slate-50">
                                <tr>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Producto</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Categoría</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Precio</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Stock</th>
                                    <th className="px-4 py-2 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Acciones</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200">
                                {products.map(product => (
                                    <tr key={product.id}>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-700">{product.name}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{product.category}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">${product.price.toFixed(2)}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{product.stock}</td>
                                        <td className="px-4 py-3 whitespace-nowrap text-sm text-right">
                                            <button onClick={() => handleEdit(product)} className="text-slate-500 hover:text-slate-800 p-1"><EditIcon /></button>
                                            <button onClick={() => handleDelete(product.id)} className="text-red-500 hover:text-red-700 p-1 ml-2"><TrashIcon /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            )}
        </div>
    );
};

export default AdminProductList;
