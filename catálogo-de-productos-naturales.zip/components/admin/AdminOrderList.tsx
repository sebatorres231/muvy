import React, { useState, useEffect } from 'react';
import { Order } from '../../types';
import { getOrders } from '../../services/orderService';

const AdminOrderList: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchOrders = async () => {
            setIsLoading(true);
            const data = await getOrders();
            setOrders(data);
            setIsLoading(false);
        };
        fetchOrders();
    }, []);

    if (isLoading) {
        return <p>Cargando pedidos...</p>;
    }
    
    if (orders.length === 0) {
        return <p>No hay pedidos para mostrar.</p>;
    }

    return (
        <div>
            <h2 className="text-xl font-bold text-slate-700 mb-4">Pedidos Recibidos</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white border border-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID Pedido</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Cliente</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Fecha</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                        {orders.map(order => (
                            <tr key={order.id}>
                                <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500 font-mono">{order.id}</td>
                                <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-700">{order.customerName}</td>
                                <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">${order.total.toFixed(2)}</td>
                                <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{new Date(order.date).toLocaleDateString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AdminOrderList;
